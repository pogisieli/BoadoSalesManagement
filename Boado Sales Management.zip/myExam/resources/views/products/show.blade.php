@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Product Details</h1>
            <p class="text-gray-600">View product information and sales history</p>
        </div>
        <div class="flex gap-3">
            <a href="{{ route('products.index') }}" class="btn">
                <i class="fas fa-arrow-left"></i>
                Back to Products
            </a>
            <a href="{{ route('products.edit', $product) }}" class="btn btn-warning">
                <i class="fas fa-edit"></i>
                Edit Product
            </a>
        </div>
    </div>
</div>

<div class="grid gap-6">
    <!-- Product Information -->
    <div class="card">
        <div class="flex items-center gap-6 mb-6">
            <div class="w-20 h-20 bg-gradient-to-br from-green-500 to-teal-500 rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">
                {{ strtoupper(substr($product->name, 0, 2)) }}
            </div>
            <div class="flex-1">
                <h2 class="text-2xl font-bold text-gray-900 mb-2">{{ $product->name }}</h2>
                <div class="flex items-center gap-4 text-gray-600">
                    <span class="flex items-center gap-2">
                        <i class="fas fa-barcode"></i>
                        SKU: {{ $product->sku }}
                    </span>
                    <span class="flex items-center gap-2">
                        <i class="fas fa-dollar-sign"></i>
                        ${{ number_format($product->price, 2) }}
                    </span>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Product Details</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Name:</span> {{ $product->name }}</p>
                    <p><span class="font-medium">SKU:</span> {{ $product->sku }}</p>
                    <p><span class="font-medium">Price:</span> ${{ number_format($product->price, 2) }}</p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Inventory</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Stock Quantity:</span> {{ $product->stock_quantity }} units</p>
                    <p><span class="font-medium">Category:</span> {{ $product->category ?: 'Uncategorized' }}</p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Sales Statistics</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Total Sales:</span> {{ $product->sales->count() }} transactions</p>
                    <p><span class="font-medium">Total Revenue:</span> ${{ number_format($product->sales->sum('total_amount'), 2) }}</p>
                </div>
            </div>
        </div>

        @if($product->description)
            <div class="mt-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Description</h3>
                <p class="text-gray-700">{{ $product->description }}</p>
            </div>
        @endif
    </div>

    <!-- Sales History -->
    @if($product->sales->count() > 0)
        <div class="card">
            <h3 class="text-xl font-bold text-gray-900 mb-6">Sales History</h3>
            <div class="grid gap-4">
                @foreach($product->sales as $sale)
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h4 class="font-semibold text-gray-900">{{ $sale->sale_number }}</h4>
                                <p class="text-sm text-gray-600">{{ $sale->customer->name }}</p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-gray-900">${{ number_format($sale->total_amount, 2) }}</p>
                                <div class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold 
                                    @if($sale->status === 'completed') bg-green-100 text-green-800
                                    @elseif($sale->status === 'pending') bg-yellow-100 text-yellow-800
                                    @else bg-red-100 text-red-800 @endif">
                                    {{ ucfirst($sale->status) }}
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-4 text-sm text-gray-600">
                            <div>
                                <span class="font-medium">Quantity:</span> {{ $sale->quantity }}
                            </div>
                            <div>
                                <span class="font-medium">Unit Price:</span> ${{ number_format($sale->unit_price, 2) }}
                            </div>
                            <div>
                                <span class="font-medium">Date:</span> {{ $sale->sale_date->format('M d, Y') }}
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @else
        <div class="card text-center">
            <div class="mb-4">
                <i class="fas fa-chart-line text-4xl text-gray-400"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">No Sales Yet</h3>
            <p class="text-gray-600 mb-6">This product hasn't been sold yet.</p>
            <a href="{{ route('sales.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i>
                Create Sale
            </a>
        </div>
    @endif
</div>
@endsection



