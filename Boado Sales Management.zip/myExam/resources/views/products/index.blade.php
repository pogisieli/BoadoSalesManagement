@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Product Management</h1>
            <p class="text-gray-600">Manage your product catalog</p>
        </div>
        <div class="flex gap-3">
            <form method="GET" action="{{ route('products.index') }}" class="flex gap-2">
                <input type="text" name="q" value="{{ $search ?? '' }}" placeholder="Search products..." class="form-control" style="min-width: 240px;" />
                <button class="btn">Search</button>
            </form>
            <a href="{{ route('products.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i>
                New Product
            </a>
        </div>
    </div>
</div>

@if($products->count() > 0)
    <div class="grid gap-6">
        @foreach($products as $product)
            <div class="student-card">
                <div class="student-info">
                    <div class="flex items-center gap-6 mb-4">
                        <div class="w-16 h-16 bg-gradient-to-br from-green-500 to-teal-500 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            {{ strtoupper(substr($product->name, 0, 2)) }}
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-box text-green-500 text-sm"></i>
                                <h3 class="text-lg font-bold text-gray-800">{{ $product->name }}</h3>
                            </div>
                            <p class="text-sm text-gray-500 font-medium">SKU: {{ $product->sku }}</p>
                        </div>
                        <div class="text-right">
                            <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                                <i class="fas fa-dollar-sign mr-1"></i>
                                ${{ number_format($product->price, 2) }}
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Description</p>
                            <p class="font-medium text-gray-800">{{ $product->description ?: 'No description available' }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Category</p>
                            <p class="font-medium text-gray-800">{{ $product->category ?: 'Uncategorized' }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Stock Quantity</p>
                            <p class="font-medium text-gray-800">{{ $product->stock_quantity }} units</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Total Sales</p>
                            <p class="font-medium text-gray-800">{{ $product->sales_count ?? 0 }} transactions</p>
                        </div>
                    </div>
                </div>
                <div class="student-actions">
                    <a href="{{ route('products.show', $product) }}" class="btn btn-info">
                        <i class="fas fa-eye"></i>
                        View Details
                    </a>
                    <a href="{{ route('products.edit', $product) }}" class="btn btn-warning">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>
                    <form action="{{ route('products.destroy', $product) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" data-confirm="true">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
    <div class="mt-6">
        {{ $products->links('vendor.pagination.pro') }}
    </div>
@else
    <div class="card text-center">
        <div class="mb-6">
            <i class="fas fa-box text-4xl text-gray-400"></i>
        </div>
        <h3 class="text-2xl font-bold text-gray-900 mb-3">No Products Found</h3>
        <p class="text-gray-600 mb-8 max-w-md mx-auto leading-relaxed">Start building your product catalog by adding your first product.</p>
        
    </div>
@endif
@endsection



