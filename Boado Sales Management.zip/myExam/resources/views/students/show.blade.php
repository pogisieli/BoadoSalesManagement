@extends('layout')

@section('title', 'Student Details')
@section('subtitle', 'View student information')

@section('content')
<div class="card">
    <div class="text-center mb-8 pb-8 border-b border-gray-200">
        <div class="w-24 h-24 bg-gradient-to-br from-blue-500 to-sage-green rounded-3xl flex items-center justify-center text-white font-bold text-3xl mx-auto mb-6 shadow-lg">
            {{ strtoupper(substr($student->fname, 0, 1)) }}{{ strtoupper(substr($student->lname, 0, 1)) }}
        </div>
        <h2 class="text-3xl font-bold text-gray-900 mb-3">{{ $student->fname }} {{ $student->mi ? $student->mi . '.' : '' }} {{ $student->lname }}</h2>
        <div class="flex items-center justify-center gap-2 text-gray-600">
            <i class="fas fa-id-card text-blue-500"></i>
            <span class="font-semibold">Student #{{ $student->studentNumber }}</span>
        </div>
    </div>

    <div class="grid gap-6 mb-8">
        <div class="form-group">
            <label class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                <i class="fas fa-id-card text-blue-500"></i>
                Student Number
            </label>
            <div class="bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200 rounded-xl p-4 text-gray-800 font-semibold text-lg">
                {{ $student->studentNumber }}
            </div>
        </div>

        <div class="form-group">
            <label class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                <i class="fas fa-user text-blue-500"></i>
                Full Name
            </label>
            <div class="bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200 rounded-xl p-4 text-gray-800 font-semibold text-lg">
                {{ $student->lname }}, {{ $student->fname }} {{ $student->mi ? $student->mi . '.' : '' }}
            </div>
        </div>

        @if($student->email)
        <div class="form-group">
            <label class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                <i class="fas fa-envelope text-blue-500"></i>
                Email Address
            </label>
            <div class="bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200 rounded-xl p-4">
                <a href="mailto:{{ $student->email }}" class="text-blue-600 hover:text-blue-800 font-semibold text-lg transition-colors duration-200">
                    {{ $student->email }}
                </a>
            </div>
        </div>
        @endif

        @if($student->contactNumber)
        <div class="form-group">
            <label class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                <i class="fas fa-phone text-blue-500"></i>
                Contact Number
            </label>
            <div class="bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200 rounded-xl p-4">
                <a href="tel:{{ $student->contactNumber }}" class="text-blue-600 hover:text-blue-800 font-semibold text-lg transition-colors duration-200">
                    {{ $student->contactNumber }}
                </a>
            </div>
        </div>
        @endif

        @if($student->section)
        <div class="form-group">
            <label class="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                <i class="fas fa-layer-group text-blue-500"></i>
                Section
            </label>
            <div class="bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200 rounded-xl p-4">
                <div class="text-gray-800 font-semibold text-lg">
                    {{ $student->section->name }} ({{ $student->section->code }})
                </div>
                @if($student->section->description)
                    <div class="text-gray-600 text-sm mt-2">
                        {{ $student->section->description }}
                    </div>
                @endif
            </div>
        </div>
        @endif
    </div>

    <div class="flex gap-4 justify-center mt-8 pt-8 border-t border-gray-200 flex-wrap">
        <a href="{{ route('students.edit', $student) }}" class="btn btn-warning">
            <i class="fas fa-edit"></i>
            Edit Student
        </a>
        <form action="{{ route('students.destroy', $student) }}" method="POST" class="inline">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger" data-confirm="true">
                <i class="fas fa-trash"></i>
                Delete Student
            </button>
        </form>
        <a href="{{ route('students.index') }}" class="btn">
            <i class="fas fa-arrow-left"></i>
            Back to List
        </a>
    </div>
</div>
@endsection
