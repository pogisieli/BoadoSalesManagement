@extends('layout')

@section('title', 'Add New Student')
@section('subtitle', 'Create a new student record')

@section('content')
<div class="card">
    <div class="mb-8">
        <div class="flex items-center gap-4 mb-4">
            <div class="w-12 h-12 bg-gradient-to-br from-sage-green to-sage-green-dark rounded-2xl flex items-center justify-center">
                <i class="fas fa-user-plus text-white text-xl"></i>
            </div>
            <div>
                <h2 class="text-3xl font-bold text-gray-900 mb-1">Add New Student</h2>
                <p class="text-gray-600">Fill in the details below to create a new student record</p>
            </div>
        </div>
    </div>

    <form action="{{ route('students.store') }}" method="POST">
        @csrf
        <div class="grid grid-cols-2 gap-6 mb-6">
            <div class="form-group">
                <label for="studentNumber" class="flex items-center gap-2">
                    <i class="fas fa-id-card text-blue-500"></i>
                    Student Number *
                </label>
                <input type="text" id="studentNumber" name="studentNumber" class="form-control" 
                       placeholder="e.g., 2024-001" value="{{ old('studentNumber') }}" required>
                @error('studentNumber')
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        {{ $message }}
                    </div>
                @enderror
            </div>

            <div class="form-group">
                <label for="mi" class="flex items-center gap-2">
                    <i class="fas fa-user text-blue-500"></i>
                    Middle Initial
                </label>
                <input type="text" id="mi" name="mi" class="form-control" 
                       placeholder="e.g., A" value="{{ old('mi') }}" maxlength="1" style="text-transform: uppercase;">
                @error('mi')
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>

        <div class="grid grid-cols-2 gap-6 mb-6">
            <div class="form-group">
                <label for="fname" class="flex items-center gap-2">
                    <i class="fas fa-user text-blue-500"></i>
                    First Name *
                </label>
                <input type="text" id="fname" name="fname" class="form-control" 
                       placeholder="Enter first name" value="{{ old('fname') }}" required>
                @error('fname')
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        {{ $message }}
                    </div>
                @enderror
            </div>

            <div class="form-group">
                <label for="lname" class="flex items-center gap-2">
                    <i class="fas fa-user text-blue-500"></i>
                    Last Name *
                </label>
                <input type="text" id="lname" name="lname" class="form-control" 
                       placeholder="Enter last name" value="{{ old('lname') }}" required>
                @error('lname')
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>

        <div class="grid grid-cols-2 gap-6 mb-6">
            <div class="form-group">
                <label for="email" class="flex items-center gap-2">
                    <i class="fas fa-envelope text-blue-500"></i>
                    Email Address
                </label>
                <input type="email" id="email" name="email" class="form-control" 
                       placeholder="student@example.com" value="{{ old('email') }}">
                @error('email')
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        {{ $message }}
                    </div>
                @enderror
            </div>

            <div class="form-group">
                <label for="contactNumber" class="flex items-center gap-2">
                    <i class="fas fa-phone text-blue-500"></i>
                    Contact Number
                </label>
                <input type="text" id="contactNumber" name="contactNumber" class="form-control" 
                       placeholder="+1 (555) 123-4567" value="{{ old('contactNumber') }}">
                @error('contactNumber')
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>

        <div class="form-group mb-8">
            <label for="section_id" class="flex items-center gap-2">
                <i class="fas fa-layer-group text-blue-500"></i>
                Section
            </label>
            <select id="section_id" name="section_id" class="form-control">
                <option value="">Select a section (optional)</option>
                @foreach($sections as $section)
                    <option value="{{ $section->id }}" {{ old('section_id') == $section->id ? 'selected' : '' }}>
                        {{ $section->name }} ({{ $section->code }})
                    </option>
                @endforeach
            </select>
            @error('section_id')
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    {{ $message }}
                </div>
            @enderror
        </div>

        <div class="flex gap-4 justify-center mt-8 pt-8 border-t border-gray-200">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i>
                Save Student
            </button>
            <a href="{{ route('students.index') }}" class="btn">
                <i class="fas fa-arrow-left"></i>
                Back to List
            </a>
        </div>
    </form>
</div>
@endsection