@extends('layout')

@section('title', 'Students List')
@section('subtitle', 'Manage your student records')

@section('content')
<div class="mb-6">
    <div class="flex justify-between items-center mb-8">
        <div>
            <div class="flex items-center gap-3 mb-2">
                <div class="w-10 h-10 bg-gradient-to-br from-blue-500 to-sage-green rounded-xl flex items-center justify-center">
                    <i class="fas fa-graduation-cap text-white text-lg"></i>
                </div>
                <h2 class="text-3xl font-bold text-gray-900">Student Directory</h2>
            </div>
            <div class="flex items-center gap-4">
                <div class="flex items-center gap-2 text-gray-600">
                    <i class="fas fa-users text-gray-400"></i>
                    <span class="font-semibold">Total Students: <span class="text-blue-600">{{ $students->count() }}</span></span>
                </div>
                @if($students->count() > 0)
                    <div class="flex items-center gap-2 text-gray-600">
                        <i class="fas fa-calendar text-gray-400"></i>
                        <span class="text-sm">Last updated: {{ now()->format('M d, Y') }}</span>
                    </div>
                @endif
            </div>
        </div>
        <div class="flex gap-3">
            <a href="{{ route('sections.index') }}" class="btn">
                <i class="fas fa-layer-group"></i>
                Manage Sections
            </a>
            <a href="{{ route('students.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i>
                Add New Student
            </a>
        </div>
    </div>
</div>

@if($students->count() > 0)
    <div class="grid gap-6">
        @foreach($students as $student)
            <div class="student-card">
                <div class="student-info">
                    <div class="flex items-center gap-6 mb-4">
                        <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-sage-green rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            {{ strtoupper(substr($student->fname, 0, 1)) }}{{ strtoupper(substr($student->lname, 0, 1)) }}
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-id-card text-blue-500 text-sm"></i>
                                <h3 class="text-lg font-bold text-gray-800">{{ $student->studentNumber }}</h3>
                            </div>
                            <p class="text-sm text-gray-500 font-medium">Student ID</p>
                        </div>
                        <div class="text-right">
                            <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                                <i class="fas fa-check-circle mr-1"></i>
                                Active
                            </div>
                        </div>
                    </div>
                    <h4 class="text-xl font-bold text-gray-900 mb-3">
                        {{ $student->lname }}, {{ $student->fname }} {{ $student->mi ? $student->mi . '.' : '' }}
                    </h4>
                    <div class="space-y-2">
                        @if($student->section)
                            <div class="flex items-center gap-3 text-sm text-gray-600">
                                <i class="fas fa-layer-group text-gray-400 w-4"></i>
                                <span class="font-medium">{{ $student->section->name }} ({{ $student->section->code }})</span>
                            </div>
                        @endif
                        @if($student->email)
                            <div class="flex items-center gap-3 text-sm text-gray-600">
                                <i class="fas fa-envelope text-gray-400 w-4"></i>
                                <span class="font-medium">{{ $student->email }}</span>
                            </div>
                        @endif
                        @if($student->contactNumber)
                            <div class="flex items-center gap-3 text-sm text-gray-600">
                                <i class="fas fa-phone text-gray-400 w-4"></i>
                                <span class="font-medium">{{ $student->contactNumber }}</span>
                            </div>
                        @endif
                    </div>
                </div>
                <div class="student-actions">
                    <a href="{{ route('students.show', $student) }}" class="btn btn-info">
                        <i class="fas fa-eye"></i>
                        View Details
                    </a>
                    <a href="{{ route('students.edit', $student) }}" class="btn btn-warning">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>
                    <form action="{{ route('students.destroy', $student) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" data-confirm="true">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
@else
    <div class="card text-center">
        <div class="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-graduation-cap text-4xl text-gray-400"></i>
        </div>
        <h3 class="text-2xl font-bold text-gray-900 mb-3">No Students Found</h3>
        <p class="text-gray-600 mb-8 max-w-md mx-auto leading-relaxed">Start building your student database by adding your first student record. This will help you manage and track student information efficiently.</p>
        <a href="{{ route('students.create') }}" class="btn btn-success">
            <i class="fas fa-plus"></i>
            Add Your First Student
        </a>
    </div>
@endif
@endsection