<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Student Management')</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #ee4d2d;
            --primary-dark: #d73502;
            --primary-light: #ff6b47;
            --secondary-color: #6b7280;
            --accent-color: #ffb86b; /* cream-ish accent tie-in */
            --cream-color: #fff4e6;
            --cream-border: #ffe1c4;
            --sage-green: #ff6b47; /* repurposed to orange for gradients already used */
            --sage-green-dark: #ee4d2d;
            --sage-green-light: #ff8a6b;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --gray-50: #f8fafc;
            --gray-100: #f1f5f9;
            --gray-200: #e2e8f0;
            --gray-300: #cbd5e1;
            --gray-400: #94a3b8;
            --gray-500: #64748b;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1e293b;
            --gray-900: #0f172a;
            --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
            --shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
            --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
            --shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #faf8f5;
            min-height: 100vh;
            color: #333333;
            line-height: 1.6;
            font-weight: 400;
            margin: 0;
            padding: 0;
        }

        .main-header {
            background: white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 1.5rem 0;
            border-bottom: 3px solid var(--primary-color);
        }

        .main-header .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .logo {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--primary-color);
            letter-spacing: -0.025em;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        /* Aesthetic pill navigation */
        .nav-pills {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem;
            background: #f3f4f6;
            border: 1px solid #e5e7eb;
            border-radius: 9999px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.04);
        }

        .nav-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 0.875rem;
            border-radius: 9999px;
            color: #374151;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            border: 1px solid transparent;
        }

        .nav-pill:hover {
            background: #ffffff;
            border-color: #e5e7eb;
            color: #111827;
            box-shadow: 0 1px 2px rgba(0,0,0,0.06);
        }

        .nav-pill.active {
            background: #ffffff;
            color: var(--primary-color);
            border-color: #e5e7eb;
            box-shadow: 0 2px 6px rgba(0,0,0,0.06);
        }

        .nav-icon {
            color: inherit;
            font-size: 0.9rem;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
            border-radius: 6px;
        }

        .container {
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            background: transparent;
            min-height: auto;
            padding: 2rem 1rem;
        }

        .header {
            background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
            border-bottom: 1px solid #4b5563;
            padding: 3rem 2rem 2rem 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="%23e2e8f0" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="%23e2e8f0" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="%23e2e8f0" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="%23e2e8f0" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="%23e2e8f0" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
        }

        .header-content {
            position: relative;
            z-index: 1;
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 0.75rem;
            font-weight: 700;
            color: #f9fafb;
            letter-spacing: -0.025em;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
        }

        .header p {
            font-size: 1.125rem;
            color: #d1d5db;
            font-weight: 400;
            max-width: 600px;
            margin: 0 auto;
        }

        .content {
            padding: 2.5rem;
            background: linear-gradient(135deg, #111827 0%, #1f2937 100%);
        }

        .card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--sage-green));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            border-color: var(--primary-color);
        }

        .card:hover::before {
            opacity: 1;
        }

        .student-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .student-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--sage-green));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .student-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            border-color: var(--primary-color);
        }

        .student-card:hover::before {
            opacity: 1;
        }

        .student-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .student-details h3 {
            color: #111827;
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
            font-weight: 600;
        }

        .student-details p {
            color: #6b7280;
            margin: 0.25rem 0;
            font-size: 0.875rem;
        }

        .student-actions {
            display: flex;
            gap: 0.5rem;
            justify-content: flex-end;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e5e7eb;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border: 1px solid transparent;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-align: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            letter-spacing: 0.025em;
            text-transform: none;
            min-height: 44px;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .btn:active {
            transform: translateY(0);
        }

        /* Unify all button variants to orange + cream accent */
        .btn-success,
        .btn-info,
        .btn-warning,
        .btn-danger {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);
            color: #ffffff;
            border-color: var(--primary-color);
            box-shadow: 0 4px 10px rgba(238, 77, 45, 0.15);
        }

        .btn-success:hover,
        .btn-info:hover,
        .btn-warning:hover,
        .btn-danger:hover {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-color) 100%);
            border-color: var(--primary-dark);
            box-shadow: 0 6px 14px rgba(238, 77, 45, 0.25);
        }

        /* Base/neutral buttons use cream background with orange accents */
        .btn:not(.btn-success):not(.btn-info):not(.btn-warning):not(.btn-danger) {
            background: var(--cream-color);
            color: var(--primary-dark);
            border-color: var(--cream-border);
            box-shadow: 0 1px 2px rgba(238, 77, 45, 0.06);
        }

        .btn:not(.btn-success):not(.btn-info):not(.btn-warning):not(.btn-danger):hover {
            background: #ffeedd;
            color: var(--primary-color);
            border-color: #ffd8b3;
            box-shadow: 0 2px 6px rgba(238, 77, 45, 0.12);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
            color: #374151;
            font-size: 0.875rem;
            letter-spacing: 0.025em;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 4px;
            font-size: 0.875rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: white;
            font-weight: 400;
            color: #374151;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(238, 77, 45, 0.1);
        }

        .form-control::placeholder {
            color: #9ca3af;
            font-weight: 400;
        }

        .form-control:hover:not(:focus) {
            border-color: #9ca3af;
        }

        .alert {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            border-left: 4px solid;
            position: relative;
            box-shadow: var(--shadow);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .alert::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 12px;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0.4) 100%);
            z-index: 0;
        }

        .alert > * {
            position: relative;
            z-index: 1;
        }

        .alert-success {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            color: #166534;
            border-left-color: var(--success-color);
        }

        .alert-success::before {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(16, 185, 129, 0.1) 100%);
        }

        .alert-danger {
            background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
            color: #991b1b;
            border-left-color: var(--danger-color);
        }

        .alert-danger::before {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.05) 0%, rgba(239, 68, 68, 0.1) 100%);
        }

        .text-center {
            text-align: center;
        }

        .mb-4 {
            margin-bottom: 1rem;
        }

        .mb-2 {
            margin-bottom: 0.5rem;
        }

        .mt-4 {
            margin-top: 1rem;
        }

        .p-4 {
            padding: 1rem;
        }

        .grid {
            display: grid;
        }

        .grid-cols-1 {
            grid-template-columns: 1fr;
        }

        .grid-cols-2 {
            grid-template-columns: repeat(2, 1fr);
        }

        .gap-4 {
            gap: 1rem;
        }

        .gap-6 {
            gap: 1.5rem;
        }

        .flex {
            display: flex;
        }

        .items-center {
            align-items: center;
        }

        .justify-between {
            justify-content: space-between;
        }

        .justify-center {
            justify-content: center;
        }

        .space-x-4 > * + * {
            margin-left: 1rem;
        }

        .w-full {
            width: 100%;
        }

        .h-8 {
            height: 2rem;
        }

        .h-12 {
            height: 3rem;
        }

        .rounded {
            border-radius: 0.375rem;
        }

        .rounded-lg {
            border-radius: 0.5rem;
        }

        .rounded-full {
            border-radius: 9999px;
        }

        .shadow {
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
        }

        .shadow-lg {
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        .text-sm {
            font-size: 0.875rem;
        }

        .text-lg {
            font-size: 1.125rem;
        }

        .text-xl {
            font-size: 1.25rem;
        }

        .text-2xl {
            font-size: 1.5rem;
        }

        .text-3xl {
            font-size: 1.875rem;
        }

        .font-medium {
            font-weight: 500;
        }

        .font-semibold {
            font-weight: 600;
        }

        .font-bold {
            font-weight: 700;
        }

        .text-gray-500 {
            color: #a0aec0;
        }

        .text-gray-600 {
            color: #718096;
        }

        .text-gray-700 {
            color: #4a5568;
        }

        .text-gray-800 {
            color: #2d3748;
        }

        .text-gray-900 {
            color: #1a202c;
        }

        .bg-gray-50 {
            background-color: #f7fafc;
        }

        .bg-gray-100 {
            background-color: #edf2f7;
        }

        .bg-gray-200 {
            background-color: #e2e8f0;
        }

        .bg-white {
            background-color: #ffffff;
        }

        .border {
            border-width: 1px;
        }

        .border-gray-200 {
            border-color: #e2e8f0;
        }

        .border-gray-300 {
            border-color: #cbd5e0;
        }

        .border-gray-400 {
            border-color: #a0aec0;
        }

        .hover\:bg-gray-50:hover {
            background-color: #f7fafc;
        }

        .hover\:bg-gray-100:hover {
            background-color: #edf2f7;
        }

        .hover\:text-gray-900:hover {
            color: #1a202c;
        }

        .focus\:outline-none:focus {
            outline: 2px solid transparent;
            outline-offset: 2px;
        }

        .focus\:ring-2:focus {
            box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.1);
        }

        .focus\:ring-blue-500:focus {
            box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.1);
        }

        .focus\:border-blue-500:focus {
            border-color: #4299e1;
        }

        .transition {
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 150ms;
        }

        .duration-200 {
            transition-duration: 200ms;
        }

        .duration-300 {
            transition-duration: 300ms;
        }

        .ease-in-out {
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Sage Green Color Classes */
        .from-sage-green {
            --tw-gradient-from: var(--sage-green);
            --tw-gradient-to: rgba(132, 204, 22, 0);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
        }

        .to-sage-green {
            --tw-gradient-to: var(--sage-green);
        }

        .to-sage-green-dark {
            --tw-gradient-to: var(--sage-green-dark);
        }

        .text-sage-green {
            color: var(--sage-green);
        }

        .bg-sage-green {
            background-color: var(--sage-green);
        }

        .border-sage-green {
            border-color: var(--sage-green);
        }

        @media (max-width: 1024px) {
            .container {
                max-width: 90%;
            }
        }

        @media (max-width: 768px) {
            .container {
                max-width: 95%;
                margin: 1rem auto;
            }

            .header {
                padding: 2rem 1.5rem 1.5rem 1.5rem;
            }

            .header h1 {
                font-size: 2rem;
            }

            .content {
                padding: 1.5rem;
            }

            .student-info {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .student-actions {
                flex-direction: column;
                gap: 0.75rem;
            }

            .btn {
                width: 100%;
                justify-content: center;
                padding: 0.875rem 1.5rem;
            }

            .grid-cols-2 {
                grid-template-columns: 1fr;
            }

            .card {
                padding: 1.5rem;
            }

            .student-card {
                padding: 1.5rem;
            }
        }

        @media (max-width: 640px) {
            .container {
                max-width: 98%;
                margin: 0.5rem auto;
            }

            .header {
                padding: 1.5rem 1rem;
            }

            .header h1 {
                font-size: 1.75rem;
            }

            .header p {
                font-size: 1rem;
            }

            .content {
                padding: 1rem;
            }

            .card {
                padding: 1.25rem;
            }

            .student-card {
                padding: 1.25rem;
            }

            .btn {
                padding: 0.75rem 1.25rem;
                font-size: 0.8rem;
            }
        }

        @media (max-width: 480px) {
            .container {
                max-width: 99%;
                margin: 0.25rem auto;
            }

            .header h1 {
                font-size: 1.5rem;
            }

            .header p {
                font-size: 0.875rem;
            }

            .card {
                padding: 1rem;
            }

            .student-card {
                padding: 1rem;
            }

            .btn {
                padding: 0.625rem 1rem;
                font-size: 0.75rem;
            }
        }
    </style>
</head>
<body>
    <!-- Main Header -->
    <div class="main-header">
        <div class="container">
            <div class="logo">Sales Management System</div>
            <div class="header-actions">
                <div class="nav-pills">
                    <a href="{{ route('customers.index') }}" class="nav-pill {{ request()->routeIs('customers.*') ? 'active' : '' }}">
                        <i class="fas fa-users nav-icon"></i>
                        Customers
                    </a>
                    <a href="{{ route('products.index') }}" class="nav-pill {{ request()->routeIs('products.*') ? 'active' : '' }}">
                        <i class="fas fa-box-open nav-icon"></i>
                        Products
                    </a>
                    <a href="{{ route('sales.index') }}" class="nav-pill {{ request()->routeIs('sales.*') ? 'active' : '' }}">
                        <i class="fas fa-receipt nav-icon"></i>
                        Sales
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container">
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger">
                {{ session('error') }}
            </div>
        @endif

        @yield('content')
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteButtons = document.querySelectorAll('.btn-danger[data-confirm]');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    if (!confirm('Are you sure you want to delete this student?')) {
                        e.preventDefault();
                    }
                });
            });
        });
    </script>
</body>
</html>