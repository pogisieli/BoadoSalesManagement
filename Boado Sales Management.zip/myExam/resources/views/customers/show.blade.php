@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Customer Details</h1>
            <p class="text-gray-600">View customer information and sales history</p>
        </div>
        <div class="flex gap-3">
            <a href="{{ route('customers.index') }}" class="btn">
                <i class="fas fa-arrow-left"></i>
                Back to Customers
            </a>
            <a href="{{ route('customers.edit', $customer) }}" class="btn btn-warning">
                <i class="fas fa-edit"></i>
                Edit Customer
            </a>
        </div>
    </div>
</div>

<div class="grid gap-6">
    <!-- Customer Information -->
    <div class="card">
        <div class="flex items-center gap-6 mb-6">
            <div class="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">
                {{ strtoupper(substr($customer->name, 0, 2)) }}
            </div>
            <div class="flex-1">
                <h2 class="text-2xl font-bold text-gray-900 mb-2">{{ $customer->name }}</h2>
                <div class="flex items-center gap-4 text-gray-600">
                    <span class="flex items-center gap-2">
                        <i class="fas fa-envelope"></i>
                        {{ $customer->email }}
                    </span>
                    <span class="flex items-center gap-2">
                        <i class="fas fa-phone"></i>
                        {{ $customer->phone }}
                    </span>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Contact Information</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Email:</span> {{ $customer->email }}</p>
                    <p><span class="font-medium">Phone:</span> {{ $customer->phone }}</p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Address</h3>
                <div class="space-y-2">
                    <p>{{ $customer->address }}</p>
                    <p>{{ $customer->city }}, {{ $customer->province }} <span class="text-gray-600">(Province)</span></p>
                    <p>{{ $customer->zip_code }}</p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Sales Statistics</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Total Sales:</span> {{ $customer->sales->count() }} transactions</p>
                    <p><span class="font-medium">Total Amount:</span> ${{ number_format($customer->sales->sum('total_amount'), 2) }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Sales History -->
    @if($customer->sales->count() > 0)
        <div class="card">
            <h3 class="text-xl font-bold text-gray-900 mb-6">Sales History</h3>
            <div class="grid gap-4">
                @foreach($customer->sales as $sale)
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h4 class="font-semibold text-gray-900">{{ $sale->sale_number }}</h4>
                                <p class="text-sm text-gray-600">{{ $sale->product->name }}</p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-gray-900">${{ number_format($sale->total_amount, 2) }}</p>
                                <div class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold 
                                    @if($sale->status === 'completed') bg-green-100 text-green-800
                                    @elseif($sale->status === 'pending') bg-yellow-100 text-yellow-800
                                    @else bg-red-100 text-red-800 @endif">
                                    {{ ucfirst($sale->status) }}
                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-4 text-sm text-gray-600">
                            <div>
                                <span class="font-medium">Quantity:</span> {{ $sale->quantity }}
                            </div>
                            <div>
                                <span class="font-medium">Unit Price:</span> ${{ number_format($sale->unit_price, 2) }}
                            </div>
                            <div>
                                <span class="font-medium">Date:</span> {{ $sale->sale_date->format('M d, Y') }}
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @else
        <div class="card text-center">
            <div class="mb-4">
                <i class="fas fa-chart-line text-4xl text-gray-400"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">No Sales Yet</h3>
            <p class="text-gray-600 mb-6">This customer hasn't made any purchases yet.</p>
            <a href="{{ route('sales.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i>
                Create Sale
            </a>
        </div>
    @endif
</div>
@endsection



