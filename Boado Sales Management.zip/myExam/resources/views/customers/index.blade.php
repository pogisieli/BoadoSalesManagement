@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Customer Management</h1>
            <p class="text-gray-600">Manage your customer database</p>
        </div>
        <div class="flex gap-3">
            <form method="GET" action="{{ route('customers.index') }}" class="flex gap-2">
                <input type="text" name="q" value="{{ $search ?? '' }}" placeholder="Search customers..." class="form-control" style="min-width: 240px;" />
                <button class="btn">Search</button>
            </form>
            <a href="{{ route('customers.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i>
                New Customer
            </a>
        </div>
    </div>
</div>

@if($customers->count() > 0)
    <div class="grid gap-6">
        @foreach($customers as $customer)
            <div class="student-card">
                <div class="student-info">
                    <div class="flex items-center gap-6 mb-4">
                        <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            {{ strtoupper(substr($customer->name, 0, 2)) }}
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-user text-blue-500 text-sm"></i>
                                <h3 class="text-lg font-bold text-gray-800">{{ $customer->name }}</h3>
                            </div>
                            <p class="text-sm text-gray-500 font-medium">{{ $customer->email }}</p>
                        </div>
                        <div class="text-right">
                            <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                                <i class="fas fa-phone mr-1"></i>
                                {{ $customer->phone }}
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Address</p>
                            <p class="font-medium text-gray-800">{{ $customer->address }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">City, Province</p>
                            <p class="font-medium text-gray-800">{{ $customer->city }}, {{ $customer->province }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Zip Code</p>
                            <p class="font-medium text-gray-800">{{ $customer->zip_code }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Total Sales</p>
                            <p class="font-medium text-gray-800">{{ $customer->sales_count ?? 0 }} transactions</p>
                        </div>
                    </div>
                </div>
                <div class="student-actions">
                    <a href="{{ route('customers.show', $customer) }}" class="btn btn-info">
                        <i class="fas fa-eye"></i>
                        View Details
                    </a>
                    <a href="{{ route('customers.edit', $customer) }}" class="btn btn-warning">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>
                    <form action="{{ route('customers.destroy', $customer) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" data-confirm="true">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
    <div class="mt-6">
        {{ $customers->links('vendor.pagination.pro') }}
    </div>
@else
    <div class="card text-center">
        <div class="mb-6">
            <i class="fas fa-users text-4xl text-gray-400"></i>
        </div>
        <h3 class="text-2xl font-bold text-gray-900 mb-3">No Customers Found</h3>
        <p class="text-gray-600 mb-8 max-w-md mx-auto leading-relaxed">Start building your customer database by adding your first customer.</p>
        
    </div>
@endif
@endsection



