@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Add New Customer</h1>
            <p class="text-gray-600">Create a new customer record</p>
        </div>
        <a href="{{ route('customers.index') }}" class="btn">
            <i class="fas fa-arrow-left"></i>
            Back to Customers
        </a>
    </div>
</div>

<div class="card">
    <form action="{{ route('customers.store') }}" method="POST">
        @csrf
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="form-group">
                <label for="name">Customer Name *</label>
                <input type="text" id="name" name="name" class="form-control" value="{{ old('name') }}" required>
                @error('name')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" class="form-control" value="{{ old('email') }}" required>
                @error('email')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="phone">Phone Number *</label>
                <input type="tel" id="phone" name="phone" class="form-control" value="{{ old('phone') }}" required>
                @error('phone')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="address">Address *</label>
                <input type="text" id="address" name="address" class="form-control" value="{{ old('address') }}" required>
                @error('address')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="city">City *</label>
                <input type="text" id="city" name="city" class="form-control" value="{{ old('city') }}" required>
                @error('city')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="province">Province *</label>
                <input type="text" id="province" name="province" class="form-control" value="{{ old('province') }}" required>
                @error('province')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="zip_code">Zip Code *</label>
                <input type="text" id="zip_code" name="zip_code" class="form-control" value="{{ old('zip_code') }}" required>
                @error('zip_code')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>
        </div>

        <div class="flex gap-4 justify-end mt-8">
            <a href="{{ route('customers.index') }}" class="btn">
                Cancel
            </a>
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i>
                Create Customer
            </button>
        </div>
    </form>
</div>
@endsection



