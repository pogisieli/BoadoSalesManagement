@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Edit Sale</h1>
            <p class="text-gray-600">Update sales transaction information</p>
        </div>
        <a href="{{ route('sales.index') }}" class="btn">
            <i class="fas fa-arrow-left"></i>
            Back to Sales
        </a>
    </div>
</div>

<div class="card">
    <form action="{{ route('sales.update', $sale) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="form-group">
                <label for="customer_id">Customer *</label>
                <select id="customer_id" name="customer_id" class="form-control" required>
                    <option value="">Select a customer</option>
                    @foreach($customers as $customer)
                        <option value="{{ $customer->id }}" {{ old('customer_id', $sale->customer_id) == $customer->id ? 'selected' : '' }}>
                            {{ $customer->name }} ({{ $customer->email }})
                        </option>
                    @endforeach
                </select>
                @error('customer_id')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="product_id">Product *</label>
                <select id="product_id" name="product_id" class="form-control" required>
                    <option value="">Select a product</option>
                    @foreach($products as $product)
                        <option value="{{ $product->id }}" {{ old('product_id', $sale->product_id) == $product->id ? 'selected' : '' }}>
                            {{ $product->name }} - ${{ number_format($product->price, 2) }} (Stock: {{ $product->stock_quantity }})
                        </option>
                    @endforeach
                </select>
                @error('product_id')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="quantity">Quantity *</label>
                <input type="number" id="quantity" name="quantity" class="form-control" min="1" value="{{ old('quantity', $sale->quantity) }}" required>
                @error('quantity')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="unit_price">Unit Price *</label>
                <input type="number" id="unit_price" name="unit_price" class="form-control" step="0.01" min="0" value="{{ old('unit_price', $sale->unit_price) }}" required>
                @error('unit_price')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="sale_date">Sale Date *</label>
                <input type="date" id="sale_date" name="sale_date" class="form-control" value="{{ old('sale_date', $sale->sale_date->format('Y-m-d')) }}" required>
                @error('sale_date')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-group">
                <label for="status">Status *</label>
                <select id="status" name="status" class="form-control" required>
                    <option value="pending" {{ old('status', $sale->status) == 'pending' ? 'selected' : '' }}>Pending</option>
                    <option value="completed" {{ old('status', $sale->status) == 'completed' ? 'selected' : '' }}>Completed</option>
                    <option value="cancelled" {{ old('status', $sale->status) == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                </select>
                @error('status')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>
        </div>

        <div class="flex gap-4 justify-end mt-8">
            <a href="{{ route('sales.index') }}" class="btn">
                Cancel
            </a>
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i>
                Update Sale
            </button>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const productSelect = document.getElementById('product_id');
    const unitPriceInput = document.getElementById('unit_price');
    
    productSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption.value) {
            // Extract price from option text (format: "Product Name - $X.XX (Stock: X)")
            const priceMatch = selectedOption.text.match(/\$([\d.]+)/);
            if (priceMatch) {
                unitPriceInput.value = priceMatch[1];
            }
        }
    });
});
</script>
@endsection



