@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Sale Details</h1>
            <p class="text-gray-600">View complete sales transaction information</p>
        </div>
        <div class="flex gap-3">
            <a href="{{ route('sales.index') }}" class="btn">
                <i class="fas fa-arrow-left"></i>
                Back to Sales
            </a>
            <a href="{{ route('sales.edit', $sale) }}" class="btn btn-warning">
                <i class="fas fa-edit"></i>
                Edit Sale
            </a>
        </div>
    </div>
</div>

<div class="grid gap-6">
    <!-- Sale Information -->
    <div class="card">
        <div class="flex items-center gap-6 mb-6">
            <div class="w-20 h-20 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">
                {{ strtoupper(substr($sale->sale_number, -2)) }}
            </div>
            <div class="flex-1">
                <h2 class="text-2xl font-bold text-gray-900 mb-2">{{ $sale->sale_number }}</h2>
                <div class="flex items-center gap-4 text-gray-600">
                    <span class="flex items-center gap-2">
                        <i class="fas fa-calendar"></i>
                        {{ $sale->sale_date->format('M d, Y') }}
                    </span>
                    <span class="flex items-center gap-2">
                        <i class="fas fa-dollar-sign"></i>
                        ${{ number_format($sale->total_amount, 2) }}
                    </span>
                </div>
            </div>
            <div class="text-right">
                <div class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold 
                    @if($sale->status === 'completed') bg-green-100 text-green-800
                    @elseif($sale->status === 'pending') bg-yellow-100 text-yellow-800
                    @else bg-red-100 text-red-800 @endif">
                    <i class="fas fa-circle mr-2"></i>
                    {{ ucfirst($sale->status) }}
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Customer Information -->
            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Customer Information</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Name:</span> {{ $sale->customer->name }}</p>
                    <p><span class="font-medium">Email:</span> {{ $sale->customer->email }}</p>
                    <p><span class="font-medium">Phone:</span> {{ $sale->customer->phone }}</p>
                    <p><span class="font-medium">Address:</span> {{ $sale->customer->address }}</p>
                </div>
            </div>

            <!-- Product Information -->
            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Product Information</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Name:</span> {{ $sale->product->name }}</p>
                    <p><span class="font-medium">SKU:</span> {{ $sale->product->sku }}</p>
                    <p><span class="font-medium">Category:</span> {{ $sale->product->category ?: 'Uncategorized' }}</p>
                    <p><span class="font-medium">Stock:</span> {{ $sale->product->stock_quantity }} units</p>
                </div>
            </div>

            <!-- Sale Details -->
            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Sale Details</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Quantity:</span> {{ $sale->quantity }}</p>
                    <p><span class="font-medium">Unit Price:</span> ${{ number_format($sale->unit_price, 2) }}</p>
                    <p><span class="font-medium">Total Amount:</span> ${{ number_format($sale->total_amount, 2) }}</p>
                    <p><span class="font-medium">Sale Date:</span> {{ $sale->sale_date->format('M d, Y') }}</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div class="flex gap-4">
            <a href="{{ route('customers.show', $sale->customer) }}" class="btn">
                <i class="fas fa-user"></i>
                View Customer
            </a>
            <a href="{{ route('products.show', $sale->product) }}" class="btn">
                <i class="fas fa-box"></i>
                View Product
            </a>
            <a href="{{ route('sales.edit', $sale) }}" class="btn btn-warning">
                <i class="fas fa-edit"></i>
                Edit Sale
            </a>
            <form action="{{ route('sales.destroy', $sale) }}" method="POST" class="inline">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger" data-confirm="true">
                    <i class="fas fa-trash"></i>
                    Delete Sale
                </button>
            </form>
        </div>
    </div>
</div>
@endsection



