@extends('layout')

@section('content')
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Sales Management</h1>
            <p class="text-gray-600">Manage your sales transactions and records</p>
        </div>
        <div class="flex gap-3">
            <form method="GET" action="{{ route('sales.index') }}" class="flex gap-2">
                <input type="text" name="q" value="{{ $search ?? '' }}" placeholder="Search sales..." class="form-control" style="min-width: 240px;" />
                <button class="btn">Search</button>
            </form>
            <a href="{{ route('sales.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i>
                New Sale
            </a>
        </div>
    </div>
</div>

@if($sales->count() > 0)
    <div class="grid gap-6">
        @foreach($sales as $sale)
            <div class="student-card">
                <div class="student-info">
                    <div class="flex items-center gap-6 mb-4">
                        <div class="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            {{ strtoupper(substr($sale->sale_number, -2)) }}
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-receipt text-red-500 text-sm"></i>
                                <h3 class="text-lg font-bold text-gray-800">{{ $sale->sale_number }}</h3>
                            </div>
                            <p class="text-sm text-gray-500 font-medium">Sale Number</p>
                        </div>
                        <div class="text-right">
                            <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold 
                                @if($sale->status === 'completed') bg-green-100 text-green-800
                                @elseif($sale->status === 'pending') bg-yellow-100 text-yellow-800
                                @else bg-red-100 text-red-800 @endif">
                                <i class="fas fa-circle mr-1"></i>
                                {{ ucfirst($sale->status) }}
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div>
                            <h4 class="text-lg font-bold text-gray-900 mb-2">Customer</h4>
                            <p class="text-gray-600">{{ $sale->customer->name }}</p>
                            <p class="text-sm text-gray-500">{{ $sale->customer->email }}</p>
                        </div>
                        <div>
                            <h4 class="text-lg font-bold text-gray-900 mb-2">Product</h4>
                            <p class="text-gray-600">{{ $sale->product->name }}</p>
                            <p class="text-sm text-gray-500">SKU: {{ $sale->product->sku }}</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-3 gap-4">
                        <div>
                            <p class="text-sm text-gray-500">Quantity</p>
                            <p class="font-semibold text-gray-900">{{ $sale->quantity }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Unit Price</p>
                            <p class="font-semibold text-gray-900">${{ number_format($sale->unit_price, 2) }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Total Amount</p>
                            <p class="font-semibold text-green-600 text-lg">${{ number_format($sale->total_amount, 2) }}</p>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-200">
                        <p class="text-sm text-gray-500">Sale Date: {{ $sale->sale_date->format('M d, Y') }}</p>
                    </div>
                </div>
                <div class="student-actions">
                    <a href="{{ route('sales.show', $sale) }}" class="btn btn-info">
                        <i class="fas fa-eye"></i>
                        View Details
                    </a>
                    <a href="{{ route('sales.edit', $sale) }}" class="btn btn-warning">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>
                    <form action="{{ route('sales.destroy', $sale) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" data-confirm="true">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
    <div class="mt-6">
        {{ $sales->links('vendor.pagination.pro') }}
    </div>
@else
    <div class="card text-center">
        <div class="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-chart-line text-4xl text-gray-400"></i>
        </div>
        <h3 class="text-2xl font-bold text-gray-900 mb-3">No Sales Found</h3>
        <p class="text-gray-600 mb-8 max-w-md mx-auto leading-relaxed">Start recording your sales transactions. You'll need to add customers and products first before creating sales.</p>
        
    </div>
@endif
@endsection
