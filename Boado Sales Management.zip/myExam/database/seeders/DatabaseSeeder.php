<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Sale;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Seed a default user
        User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);

        // Seed 100 Customers
        $customers = collect(range(1, 100))->map(function ($i) {
            return [
                'name' => 'Customer ' . $i,
                'email' => 'customer' . $i . '@example.com',
                'phone' => '+63 9' . rand(10, 99) . ' ' . rand(100, 999) . ' ' . rand(1000, 9999),
                'address' => 'Street ' . rand(1, 200) . ', Barangay ' . rand(1, 100),
                'city' => 'City ' . rand(1, 50),
                'province' => 'Province ' . rand(1, 30),
                'zip_code' => (string) rand(1000, 9999),
                'created_at' => now()->subDays(rand(0, 120)),
                'updated_at' => now(),
            ];
        });
        Customer::insert($customers->all());

        // Seed 100 Products
        $products = collect(range(1, 100))->map(function ($i) {
            return [
                'name' => 'Product ' . $i,
                'sku' => 'SKU-' . Str::upper(Str::random(6)) . $i,
                'description' => 'Sample product description #' . $i,
                'price' => rand(50, 5000) / 1,
                'stock_quantity' => rand(0, 500),
                'category' => 'Category ' . rand(1, 10),
                'created_at' => now()->subDays(rand(0, 120)),
                'updated_at' => now(),
            ];
        });
        Product::insert($products->all());

        // Seed 100 Sales
        $customerIds = Customer::pluck('id');
        $productIds = Product::pluck('id');

        $sales = collect(range(1, 100))->map(function ($i) use ($customerIds, $productIds) {
            $quantity = rand(1, 10);
            $unitPrice = rand(100, 10000) / 100;
            return [
                'sale_number' => 'SALE-' . str_pad($i, 6, '0', STR_PAD_LEFT),
                'customer_id' => $customerIds->random(),
                'product_id' => $productIds->random(),
                'quantity' => $quantity,
                'unit_price' => $unitPrice,
                'total_amount' => $quantity * $unitPrice,
                'sale_date' => now()->subDays(rand(0, 120)),
                'status' => collect(['pending', 'completed', 'cancelled'])->random(),
                'created_at' => now()->subDays(rand(0, 120)),
                'updated_at' => now(),
            ];
        });
        Sale::insert($sales->all());
    }
}
