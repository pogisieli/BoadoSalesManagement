<?php

namespace App\Models; 
use Illuminate\Database\Eloquent\Factories\HasFactory; 
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Student extends Model 
{ 
use HasFactory; 
protected $table = 'studs';
protected $fillable = [ 
'studentNumber', 'lname', 'fname', 'mi', 'email', 'contactNumber', 'section_id'
]; 

/**
 * Get the section that owns the student.
 */
public function section(): BelongsTo
{
    return $this->belongsTo(Section::class);
}
} 
