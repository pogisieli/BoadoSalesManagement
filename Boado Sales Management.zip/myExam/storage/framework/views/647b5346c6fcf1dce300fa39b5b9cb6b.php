

<?php $__env->startSection('title', 'Add New Section'); ?>
<?php $__env->startSection('subtitle', 'Create a new section record'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="mb-8">
        <div class="flex items-center gap-4 mb-4">
            <div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-sage-green rounded-2xl flex items-center justify-center">
                <i class="fas fa-layer-group text-white text-xl"></i>
            </div>
            <div>
                <h2 class="text-3xl font-bold text-gray-900 mb-1">Add New Section</h2>
                <p class="text-gray-600">Fill in the details below to create a new section</p>
            </div>
        </div>
    </div>

    <form action="<?php echo e(route('sections.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="grid grid-cols-2 gap-6 mb-6">
            <div class="form-group">
                <label for="name" class="flex items-center gap-2">
                    <i class="fas fa-layer-group text-purple-500"></i>
                    Section Name *
                </label>
                <input type="text" id="name" name="name" class="form-control" 
                       placeholder="e.g., Computer Science 101" value="<?php echo e(old('name')); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="code" class="flex items-center gap-2">
                    <i class="fas fa-code text-purple-500"></i>
                    Section Code *
                </label>
                <input type="text" id="code" name="code" class="form-control" 
                       placeholder="e.g., CS101" value="<?php echo e(old('code')); ?>" required style="text-transform: uppercase;">
                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group mb-8">
            <label for="description" class="flex items-center gap-2">
                <i class="fas fa-info-circle text-purple-500"></i>
                Description
            </label>
            <textarea id="description" name="description" class="form-control" rows="4" 
                      placeholder="Enter section description (optional)"><?php echo e(old('description')); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex gap-4 justify-center mt-8 pt-8 border-t border-gray-200">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i>
                Save Section
            </button>
            <a href="<?php echo e(route('sections.index')); ?>" class="btn">
                <i class="fas fa-arrow-left"></i>
                Back to List
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myExam\resources\views/sections/create.blade.php ENDPATH**/ ?>