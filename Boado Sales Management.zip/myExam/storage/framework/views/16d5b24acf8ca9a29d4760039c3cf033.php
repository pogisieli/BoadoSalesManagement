<style>
    /* Scoped component styles to match provided design */
    .pro-pagination-wrapper {
        position: sticky;
        bottom: 0;
        left: 0;
        right: 0;
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 8px 10px;
        background: transparent;
        z-index: 30;
    }
    .pro-pagination {
        background: color-mix(in sRGB, var(--cream-color, #fff4e6) 80%, #ffffff 20%);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 14px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.08);
        border: 1px solid var(--pagination-border-color, var(--cream-border, #ffe1c4));
        display: inline-block;
    }
    .pro-pagination .pagination {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .pro-pagination .pagination-item {
        display: flex;
        align-items: center;
        justify-content: center;
        min-width: 44px;
        height: 44px;
        border: 2px solid var(--pagination-item-border, var(--cream-border, #ffe1c4));
        border-radius: 10px;
        background: var(--pagination-item-bg, #ffffff);
        color: var(--pagination-item-fg, #4a5568);
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        user-select: none;
        position: relative;
        overflow: hidden;
    }
    .pro-pagination .pagination-item::before {
        content: '';
        position: absolute;
        top: 0; left: -100%;
        width: 100%; height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.8), transparent);
        transition: left 0.5s;
    }
    .pro-pagination .pagination-item:hover::before { left: 100%; }
    .pro-pagination .pagination-item:hover {
        border-color: var(--primary-color, #ee4d2d);
        background: linear-gradient(135deg, var(--primary-color, #ee4d2d), var(--primary-light, #ff6b47));
        color: var(--on-primary, #ffffff);
        transform: translateY(-2px);
        box-shadow: 0 10px 20px color-mix(in sRGB, var(--primary-color, #ee4d2d) 30%, transparent);
    }
    .pro-pagination .pagination-item.active {
        background: linear-gradient(135deg, var(--primary-color, #ee4d2d), var(--primary-light, #ff6b47));
        border-color: var(--primary-color, #ee4d2d);
        color: var(--on-primary, #ffffff);
        box-shadow: 0 8px 16px color-mix(in sRGB, var(--primary-color, #ee4d2d) 40%, transparent);
        transform: translateY(-1px);
    }
    .pro-pagination .pagination-item.active:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 24px color-mix(in sRGB, var(--primary-color, #ee4d2d) 50%, transparent);
    }
    .pro-pagination .pagination-item.disabled,
    .pro-pagination .pagination-item.disabled:hover {
        background: var(--pagination-disabled-bg, #fff7ef);
        color: var(--pagination-disabled-fg, #c4a48f);
        border-color: var(--pagination-disabled-border, var(--cream-border, #ffe1c4));
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }
    .pro-pagination .prev-next { padding: 0 16px; min-width: 80px; font-weight: 700; }
    @media (max-width: 600px) {
        .pro-pagination .pagination { gap: 4px; }
        .pro-pagination .pagination-item { min-width: 40px; height: 40px; font-size: 13px; }
        .pro-pagination .prev-next { min-width: 70px; padding: 0 12px; }
    }
</style>

<?php if($paginator->hasPages()): ?>
    <div class="pro-pagination-wrapper">
        <nav class="pro-pagination" aria-label="Pagination">
            <div class="pagination">
            
            <?php if($paginator->onFirstPage()): ?>
                <span class="pagination-item prev-next disabled" aria-disabled="true" aria-label="Previous">Previous</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pagination-item prev-next" rel="prev" aria-label="Previous">Previous</a>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <span class="pagination-item disabled" aria-disabled="true"><?php echo e($element); ?></span>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <span class="pagination-item active" aria-current="page"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="pagination-item"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pagination-item prev-next" rel="next" aria-label="Next">Next</a>
            <?php else: ?>
                <span class="pagination-item prev-next disabled" aria-disabled="true" aria-label="Next">Next</span>
            <?php endif; ?>
            </div>
        </nav>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\myExam\resources\views/vendor/pagination/pro.blade.php ENDPATH**/ ?>