

<?php $__env->startSection('content'); ?>
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Customer Details</h1>
            <p class="text-gray-600">View customer information and sales history</p>
        </div>
        <div class="flex gap-3">
            <a href="<?php echo e(route('customers.index')); ?>" class="btn">
                <i class="fas fa-arrow-left"></i>
                Back to Customers
            </a>
            <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="btn btn-warning">
                <i class="fas fa-edit"></i>
                Edit Customer
            </a>
        </div>
    </div>
</div>

<div class="grid gap-6">
    <!-- Customer Information -->
    <div class="card">
        <div class="flex items-center gap-6 mb-6">
            <div class="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">
                <?php echo e(strtoupper(substr($customer->name, 0, 2))); ?>

            </div>
            <div class="flex-1">
                <h2 class="text-2xl font-bold text-gray-900 mb-2"><?php echo e($customer->name); ?></h2>
                <div class="flex items-center gap-4 text-gray-600">
                    <span class="flex items-center gap-2">
                        <i class="fas fa-envelope"></i>
                        <?php echo e($customer->email); ?>

                    </span>
                    <span class="flex items-center gap-2">
                        <i class="fas fa-phone"></i>
                        <?php echo e($customer->phone); ?>

                    </span>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Contact Information</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Email:</span> <?php echo e($customer->email); ?></p>
                    <p><span class="font-medium">Phone:</span> <?php echo e($customer->phone); ?></p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Address</h3>
                <div class="space-y-2">
                    <p><?php echo e($customer->address); ?></p>
                    <p><?php echo e($customer->city); ?>, <?php echo e($customer->province); ?> <span class="text-gray-600">(Province)</span></p>
                    <p><?php echo e($customer->zip_code); ?></p>
                </div>
            </div>

            <div>
                <h3 class="text-lg font-semibold text-gray-900 mb-3">Sales Statistics</h3>
                <div class="space-y-2">
                    <p><span class="font-medium">Total Sales:</span> <?php echo e($customer->sales->count()); ?> transactions</p>
                    <p><span class="font-medium">Total Amount:</span> $<?php echo e(number_format($customer->sales->sum('total_amount'), 2)); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Sales History -->
    <?php if($customer->sales->count() > 0): ?>
        <div class="card">
            <h3 class="text-xl font-bold text-gray-900 mb-6">Sales History</h3>
            <div class="grid gap-4">
                <?php $__currentLoopData = $customer->sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h4 class="font-semibold text-gray-900"><?php echo e($sale->sale_number); ?></h4>
                                <p class="text-sm text-gray-600"><?php echo e($sale->product->name); ?></p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-gray-900">$<?php echo e(number_format($sale->total_amount, 2)); ?></p>
                                <div class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold 
                                    <?php if($sale->status === 'completed'): ?> bg-green-100 text-green-800
                                    <?php elseif($sale->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                    <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                                    <?php echo e(ucfirst($sale->status)); ?>

                                </div>
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-4 text-sm text-gray-600">
                            <div>
                                <span class="font-medium">Quantity:</span> <?php echo e($sale->quantity); ?>

                            </div>
                            <div>
                                <span class="font-medium">Unit Price:</span> $<?php echo e(number_format($sale->unit_price, 2)); ?>

                            </div>
                            <div>
                                <span class="font-medium">Date:</span> <?php echo e($sale->sale_date->format('M d, Y')); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <div class="card text-center">
            <div class="mb-4">
                <i class="fas fa-chart-line text-4xl text-gray-400"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">No Sales Yet</h3>
            <p class="text-gray-600 mb-6">This customer hasn't made any purchases yet.</p>
            <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i>
                Create Sale
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myExam\resources\views/customers/show.blade.php ENDPATH**/ ?>