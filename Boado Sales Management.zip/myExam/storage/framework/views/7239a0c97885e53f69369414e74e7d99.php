

<?php $__env->startSection('content'); ?>
<div class="mb-8">
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Customer Management</h1>
            <p class="text-gray-600">Manage your customer database</p>
        </div>
        <div class="flex gap-3">
            <form method="GET" action="<?php echo e(route('customers.index')); ?>" class="flex gap-2">
                <input type="text" name="q" value="<?php echo e($search ?? ''); ?>" placeholder="Search customers..." class="form-control" style="min-width: 240px;" />
                <button class="btn">Search</button>
            </form>
            <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i>
                New Customer
            </a>
        </div>
    </div>
</div>

<?php if($customers->count() > 0): ?>
    <div class="grid gap-6">
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="student-card">
                <div class="student-info">
                    <div class="flex items-center gap-6 mb-4">
                        <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            <?php echo e(strtoupper(substr($customer->name, 0, 2))); ?>

                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-user text-blue-500 text-sm"></i>
                                <h3 class="text-lg font-bold text-gray-800"><?php echo e($customer->name); ?></h3>
                            </div>
                            <p class="text-sm text-gray-500 font-medium"><?php echo e($customer->email); ?></p>
                        </div>
                        <div class="text-right">
                            <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">
                                <i class="fas fa-phone mr-1"></i>
                                <?php echo e($customer->phone); ?>

                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Address</p>
                            <p class="font-medium text-gray-800"><?php echo e($customer->address); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">City, Province</p>
                            <p class="font-medium text-gray-800"><?php echo e($customer->city); ?>, <?php echo e($customer->province); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Zip Code</p>
                            <p class="font-medium text-gray-800"><?php echo e($customer->zip_code); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500 mb-1">Total Sales</p>
                            <p class="font-medium text-gray-800"><?php echo e($customer->sales_count ?? 0); ?> transactions</p>
                        </div>
                    </div>
                </div>
                <div class="student-actions">
                    <a href="<?php echo e(route('customers.show', $customer)); ?>" class="btn btn-info">
                        <i class="fas fa-eye"></i>
                        View Details
                    </a>
                    <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="btn btn-warning">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>
                    <form action="<?php echo e(route('customers.destroy', $customer)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" data-confirm="true">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-6">
        <?php echo e($customers->links('vendor.pagination.pro')); ?>

    </div>
<?php else: ?>
    <div class="card text-center">
        <div class="mb-6">
            <i class="fas fa-users text-4xl text-gray-400"></i>
        </div>
        <h3 class="text-2xl font-bold text-gray-900 mb-3">No Customers Found</h3>
        <p class="text-gray-600 mb-8 max-w-md mx-auto leading-relaxed">Start building your customer database by adding your first customer.</p>
        
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myExam\resources\views/customers/index.blade.php ENDPATH**/ ?>