

<?php $__env->startSection('title', 'Sections List'); ?>
<?php $__env->startSection('subtitle', 'Manage your section records'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <div class="flex justify-between items-center mb-8">
        <div>
            <div class="flex items-center gap-3 mb-2">
                <div class="w-10 h-10 bg-gradient-to-br from-purple-500 to-sage-green rounded-xl flex items-center justify-center">
                    <i class="fas fa-layer-group text-white text-lg"></i>
                </div>
                <h2 class="text-3xl font-bold text-gray-900">Section Directory</h2>
            </div>
            <div class="flex items-center gap-4">
                <div class="flex items-center gap-2 text-gray-600">
                    <i class="fas fa-layer-group text-gray-400"></i>
                    <span class="font-semibold">Total Sections: <span class="text-purple-600"><?php echo e($sections->count()); ?></span></span>
                </div>
                <?php if($sections->count() > 0): ?>
                    <div class="flex items-center gap-2 text-gray-600">
                        <i class="fas fa-calendar text-gray-400"></i>
                        <span class="text-sm">Last updated: <?php echo e(now()->format('M d, Y')); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="flex gap-3">
            <a href="<?php echo e(route('students.index')); ?>" class="btn">
                <i class="fas fa-graduation-cap"></i>
                Manage Students
            </a>
            <a href="<?php echo e(route('sections.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i>
                Add New Section
            </a>
        </div>
    </div>
</div>

<?php if($sections->count() > 0): ?>
    <div class="grid gap-6">
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="student-card">
                <div class="student-info">
                    <div class="flex items-center gap-6 mb-4">
                        <div class="w-16 h-16 bg-gradient-to-br from-purple-500 to-sage-green rounded-2xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
                            <?php echo e(strtoupper(substr($section->name, 0, 2))); ?>

                        </div>
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                <i class="fas fa-code text-purple-500 text-sm"></i>
                                <h3 class="text-lg font-bold text-gray-800"><?php echo e($section->code); ?></h3>
                            </div>
                            <p class="text-sm text-gray-500 font-medium">Section Code</p>
                        </div>
                        <div class="text-right">
                            <div class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                                <i class="fas fa-users mr-1"></i>
                                <?php echo e($section->students_count); ?> students
                            </div>
                        </div>
                    </div>
                    <h4 class="text-xl font-bold text-gray-900 mb-3">
                        <?php echo e($section->name); ?>

                    </h4>
                    <div class="space-y-2">
                        <?php if($section->description): ?>
                            <div class="flex items-center gap-3 text-sm text-gray-600">
                                <i class="fas fa-info-circle text-gray-400 w-4"></i>
                                <span class="font-medium"><?php echo e($section->description); ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="flex items-center gap-3 text-sm text-gray-600">
                            <i class="fas fa-calendar text-gray-400 w-4"></i>
                            <span class="font-medium">Created: <?php echo e($section->created_at->format('M d, Y')); ?></span>
                        </div>
                    </div>
                </div>
                <div class="student-actions">
                    <a href="<?php echo e(route('sections.show', $section)); ?>" class="btn btn-info">
                        <i class="fas fa-eye"></i>
                        View Details
                    </a>
                    <a href="<?php echo e(route('sections.edit', $section)); ?>" class="btn btn-warning">
                        <i class="fas fa-edit"></i>
                        Edit
                    </a>
                    <form action="<?php echo e(route('sections.destroy', $section)); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" data-confirm="true">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
    <div class="card text-center">
        <div class="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-layer-group text-4xl text-gray-400"></i>
        </div>
        <h3 class="text-2xl font-bold text-gray-900 mb-3">No Sections Found</h3>
        <p class="text-gray-600 mb-8 max-w-md mx-auto leading-relaxed">Start building your section database by adding your first section. This will help you organize students into different groups.</p>
        <a href="<?php echo e(route('sections.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus"></i>
            Add Your First Section
        </a>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myExam\resources\views/sections/index.blade.php ENDPATH**/ ?>