<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SaleController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('sales.index');
});

// Customer routes
Route::resource('customers', CustomerController::class);

// Product routes
Route::resource('products', ProductController::class);

// Sale routes
Route::resource('sales', SaleController::class);